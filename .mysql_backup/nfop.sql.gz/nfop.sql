-- MySQL dump 10.13  Distrib 5.6.47, for Linux (x86_64)
--
-- Host: localhost    Database: nfop
-- ------------------------------------------------------
-- Server version	5.6.47-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `nfop`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `nfop` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `nfop`;

--
-- Table structure for table `logins`
--

DROP TABLE IF EXISTS `logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logins` (
  `officer` tinyint(1) NOT NULL DEFAULT '0',
  `first_name` varchar(15) NOT NULL,
  `last_name` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(2) NOT NULL,
  `zip` varchar(5) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(12) NOT NULL,
  `password` varchar(32) NOT NULL,
  `fop_form` varchar(50) DEFAULT NULL,
  `license` varchar(50) DEFAULT NULL,
  `registration` varchar(60) DEFAULT NULL,
  `session` varchar(50) DEFAULT NULL,
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logins`
--

LOCK TABLES `logins` WRITE;
/*!40000 ALTER TABLE `logins` DISABLE KEYS */;
INSERT INTO `logins` VALUES (0,'Bob','Smith','90 Lexington Dr.','Lakewood','NJ','08701','','lasota.damian@yahoo.com','Username','022b5ac7ea72a5ee3bfc6b3eb461f2fc','uploads/Smith_Bob_fop_form','uploads/Smith_Bob_license','uploads/Smith_Bob_registration','c9375ba23a9db220b1bf430e4df8fb1f'),(1,'John','Doe','8584 Long Ave.','Cliffside Park','NJ','07010','','dl781@scarletmail.rutgers.edu','TestOfficer','0cef1fb10f60529028a71f58e54ed07b','','','',''),(1,'Kunal','Dawar','3 Pegasus Trail','Sparta','NJ','07871','9736004900','kndawar@aol.com','kndawar','5e236351fe46e757957d71f4dbaa1a4b','uploads/Dawar_Kunal_fop_form','uploads/Dawar_Kunal_license','uploads/Dawar_Kunal_registration',''),(0,'Pareen','Desai','85 papscoe drive','parsippany','NJ','07054','','pnd22@scarletmail.rutgers.edu','pnd22','6fde8cb09eb4a85ece082aab4e3fa483',NULL,NULL,NULL,'e9ef12b9eb6df9db0a59a21aa9b8d44e'),(0,'Carolina','Gonzalez','195 University ave','Newark','NJ','07102','','piphero85@gmail.com','cg667','aa4d3a6f18cdc1c1c09e568be711cd20','uploads/Gonzalez_Carolina_fop_form','uploads/Gonzalez_Carolina_license','uploads/Gonzalez_Carolina_registration','c6e8e21c3a40b0d1c655371f8f3893e6'),(0,'juliana','ceballos','123 street','newark','NJ','07206','','jaceballos9@gmail.com','juliana123','82080600934821faf0bc59cba79964bc',NULL,NULL,NULL,NULL),(0,'Matthew','Ricio','36 Wellington Road','East Brunswick','NJ','08816','7323257469','markricio@gmail.com','mattricio','b5bd5bad29f76ba8d0aadcf409ea473c',NULL,NULL,NULL,'0ab920ee0225c109f5aac667ad76c359');
/*!40000 ALTER TABLE `logins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'nfop'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-11 13:26:34
